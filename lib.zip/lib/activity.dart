import 'package:flutter/material.dart';
import 'grpmodel.dart';
import 'dummydata.dart';

class ActivityPage extends StatelessWidget {
  const ActivityPage({Key? key}) : super(key: key);

  final Color primaryPurple = const Color(0xFF982598);
  final Color lightBg = const Color(0xFFF1E9E9);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: lightBg,
      appBar: AppBar(
        title: const Text("Activity"),
        backgroundColor: primaryPurple,
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(12),
        itemCount: activities.length,
        itemBuilder: (context, index) {
          final activity = activities[index];
          return _buildActivityCard(activity);
        },
      ),
    );
  }

  Widget _buildActivityCard(ActivityModel activity) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text.rich(
              TextSpan(
                style: const TextStyle(fontSize: 14, color: Colors.black),
                children: [
                  TextSpan(
                    text: "${activity.userName} ",
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  TextSpan(text: _getActionText(activity)),
                ],
              ),
            ),
            const SizedBox(height: 6),
            Row(
              children: [
                Icon(Icons.group, size: 16, color: primaryPurple),
                const SizedBox(width: 4),
                Text(
                  "in ${activity.groupName}",
                  style: TextStyle(
                    color: primaryPurple,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 6),
            Text(
              _formatTime(activity.timestamp),
              style: const TextStyle(fontSize: 12, color: Colors.grey),
            ),
          ],
        ),
      ),
    );
  }

  String _getActionText(ActivityModel activity) {
    if (activity.type == "expense") {
      return "added ${activity.title} (₹${activity.amount?.toStringAsFixed(0)})";
    } else if (activity.type == "settlement") {
      return "settled ₹${activity.amount?.toStringAsFixed(0)}";
    } else if (activity.type == "group") {
      return "joined the group";
    }
    return "";
  }

  String _formatTime(DateTime time) {
    final diff = DateTime.now().difference(time);

    if (diff.inHours < 1) {
      return "${diff.inMinutes} mins ago";
    } else if (diff.inHours < 24) {
      return "${diff.inHours} hrs ago";
    } else {
      return "${diff.inDays} days ago";
    }
  }
}
